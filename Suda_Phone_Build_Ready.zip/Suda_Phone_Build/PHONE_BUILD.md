# Suda — phone-only APK build

The project is prepared for a cloud build from a phone.

## Easiest route: GitHub Actions

1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository, e.g. `Suda`.
3. Upload the complete contents of this project to the repository (not just the ZIP).
4. Open the repository's **Actions** tab.
5. Select **Build Suda APK**.
6. Tap **Run workflow**.
7. After the workflow finishes, open the completed run.
8. In **Artifacts**, download `Suda-debug-apk`.
9. Extract it and install `app-debug.apk` on your Android phone.

## Important

The repository must contain the project files at the repository root, including:
- `settings.gradle`
- `build.gradle`
- `gradle.properties`
- `app/`
- `.github/workflows/build-apk.yml`

This is a debug APK for testing. For Play Store/release distribution, create a signed release build later.

## Test

Install Suda on two Android phones, grant the requested nearby/Bluetooth permissions, open Suda on both phones, tap **डिवाइस खोजें व कनेक्ट करें**, then test text messaging.
