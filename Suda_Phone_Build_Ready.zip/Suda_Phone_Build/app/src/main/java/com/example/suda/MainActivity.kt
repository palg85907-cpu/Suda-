package com.example.suda

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import java.nio.charset.StandardCharsets

class MainActivity : AppCompatActivity() {

    companion object {
        private const val SERVICE_ID = "com.example.suda.offline"
        private const val PERMISSION_REQUEST_CODE = 100
        private val STRATEGY = Strategy.P2P_CLUSTER
    }

    private val connectionsClient by lazy { Nearby.getConnectionsClient(this) }

    private lateinit var tvStatus: TextView
    private lateinit var tvMessages: TextView
    private lateinit var etMessage: EditText
    private lateinit var btnConnect: Button
    private lateinit var btnSend: Button

    private val connectedEndpoints = mutableSetOf<String>()
    private val pendingEndpoints = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvMessages = findViewById(R.id.tvMessages)
        etMessage = findViewById(R.id.etMessage)
        btnConnect = findViewById(R.id.btnConnect)
        btnSend = findViewById(R.id.btnSend)

        btnConnect.setOnClickListener {
            if (hasRequiredPermissions()) {
                startSuda()
            } else {
                requestRequiredPermissions()
            }
        }

        btnSend.setOnClickListener {
            sendCurrentMessage()
        }

        etMessage.setOnEditorActionListener { _, _, _ ->
            sendCurrentMessage()
            true
        }

        if (!hasRequiredPermissions()) {
            requestRequiredPermissions()
        }
    }

    private fun startSuda() {
        startAdvertising()
        startDiscovery()
        btnConnect.isEnabled = false
        tvStatus.text = getString(R.string.status_searching)
        appendSystemMessage("Suda आसपास के compatible devices खोज रहा है…")
    }

    private fun startAdvertising() {
        val options = AdvertisingOptions.Builder()
            .setStrategy(STRATEGY)
            .build()

        connectionsClient
            .startAdvertising(
                deviceName(),
                SERVICE_ID,
                connectionLifecycleCallback,
                options
            )
            .addOnFailureListener { error ->
                tvStatus.text = getString(R.string.status_error, error.message ?: "Unknown error")
            }
    }

    private fun startDiscovery() {
        val options = DiscoveryOptions.Builder()
            .setStrategy(STRATEGY)
            .build()

        connectionsClient
            .startDiscovery(
                SERVICE_ID,
                endpointDiscoveryCallback,
                options
            )
            .addOnFailureListener { error ->
                tvStatus.text = getString(R.string.status_error, error.message ?: "Unknown error")
            }
    }

    private fun deviceName(): String {
        val model = Build.MODEL?.takeIf { it.isNotBlank() } ?: "Android"
        return "Suda-$model"
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(
            endpointId: String,
            info: DiscoveredEndpointInfo
        ) {
            if (connectedEndpoints.contains(endpointId) || pendingEndpoints.contains(endpointId)) {
                return
            }

            pendingEndpoints.add(endpointId)

            connectionsClient.requestConnection(
                deviceName(),
                endpointId,
                connectionLifecycleCallback
            ).addOnFailureListener {
                pendingEndpoints.remove(endpointId)
            }
        }

        override fun onEndpointLost(endpointId: String) {
            pendingEndpoints.remove(endpointId)
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {

        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            // For this local/offline prototype, connections are accepted automatically.
            connectionsClient.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(
            endpointId: String,
            result: ConnectionResolution
        ) {
            pendingEndpoints.remove(endpointId)

            if (result.status.isSuccess) {
                connectedEndpoints.add(endpointId)
                updateConnectionStatus()
                appendSystemMessage("एक nearby device Suda से जुड़ गया।")
            } else {
                updateConnectionStatus()
            }
        }

        override fun onDisconnected(endpointId: String) {
            pendingEndpoints.remove(endpointId)
            connectedEndpoints.remove(endpointId)
            updateConnectionStatus()
            appendSystemMessage("एक device disconnect हो गया।")
        }
    }

    private val payloadCallback = object : PayloadCallback() {

        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return

            val bytes = payload.asBytes() ?: return
            val receivedMessage = String(bytes, StandardCharsets.UTF_8)

            runOnUiThread {
                tvMessages.append("\n\nमित्र: $receivedMessage")
            }
        }

        override fun onPayloadTransferUpdate(
            endpointId: String,
            update: PayloadTransferUpdate
        ) = Unit
    }

    private fun sendCurrentMessage(): Boolean {
        val message = etMessage.text.toString().trim()

        if (message.isEmpty()) {
            return false
        }

        if (connectedEndpoints.isEmpty()) {
            Toast.makeText(
                this,
                getString(R.string.no_connection),
                Toast.LENGTH_SHORT
            ).show()
            return false
        }

        val payload = Payload.fromBytes(
            message.toByteArray(StandardCharsets.UTF_8)
        )

        connectionsClient.sendPayload(connectedEndpoints.toList(), payload)
            .addOnFailureListener { error ->
                Toast.makeText(
                    this,
                    "मैसेज नहीं भेजा गया: ${error.message ?: "Unknown error"}",
                    Toast.LENGTH_SHORT
                ).show()
            }

        tvMessages.append("\n\nमैं: $message")
        etMessage.text.clear()
        return true
    }

    private fun updateConnectionStatus() {
        runOnUiThread {
            val count = connectedEndpoints.size
            tvStatus.text = when {
                count == 0 -> getString(R.string.status_disconnected)
                count == 1 -> getString(R.string.status_connected_one)
                else -> getString(R.string.status_connected_many, count)
            }
        }
    }

    private fun appendSystemMessage(message: String) {
        runOnUiThread {
            tvMessages.append("\n\n• $message")
        }
    }

    private fun hasRequiredPermissions(): Boolean {
        return requiredPermissions().all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requiredPermissions(): List<String> {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions += Manifest.permission.BLUETOOTH_SCAN
            permissions += Manifest.permission.BLUETOOTH_ADVERTISE
            permissions += Manifest.permission.BLUETOOTH_CONNECT
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.NEARBY_WIFI_DEVICES
        }

        return permissions
    }

    private fun requestRequiredPermissions() {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                missing.toTypedArray(),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults.all {
                    it == PackageManager.PERMISSION_GRANTED
                }) {
                Toast.makeText(
                    this,
                    "Permissions मिल गईं। अब 'डिवाइस खोजें' दबाएँ।",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "Suda को nearby devices खोजने के लिए permissions चाहिए।",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroy() {
        connectionsClient.stopAdvertising()
        connectionsClient.stopDiscovery()
        connectionsClient.stopAllEndpoints()
        super.onDestroy()
    }
}
